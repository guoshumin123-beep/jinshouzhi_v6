# Market Data相关

> 文档来源：https://www.htx.com/zh-cn/opend/newApiPages/?id=5498


