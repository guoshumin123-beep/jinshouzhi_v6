# Websocket资产及订单

> 文档来源：https://www.htx.com/zh-cn/opend/newApiPages/?id=89


